"use strict"
let obj = {
    a: ['a', 'b', 'c',],
    b: '111',
    c: 'eee',
};
let str = JSON.stringify(obj);
console.log(str);