"use strict"
let obj = {
    a: 1,
    b: 2,
    c: 'eee',
    d: true,
};
let str = JSON.stringify(obj);
console.log(str);