"use strict"
let set = new Set();
set.add(11);
set.add(12);
set.add(13);
set.add(14);
set.add(15);
set.add(16);
set.add(11);
console.log(set);