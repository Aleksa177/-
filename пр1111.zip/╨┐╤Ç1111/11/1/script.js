"use strict"
let elem = document.querySelector('#elem');
elem.addEventListener('click', function() {
    elem.classList.toggle('active')
})