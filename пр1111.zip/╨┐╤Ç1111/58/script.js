"use strict"
let sym1 = Symbol.for('test1');
let sym2 = Symbol.for('test2');
let key1 = Symbol.keyFor('test1');
let key2 = Symbol.keyFor('test2');
console.log(key1);
console.log(key2);